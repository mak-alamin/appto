<?php
// Tabs
$this->start_controls_section(
    'image_carousel_style',
    [
        'label' => __('Images', 'appto-extension'),
        'tab' => \Elementor\Controls_Manager::TAB_STYLE,
    ]
);


$this->end_controls_section();